DUEL LINKS META - PROYECTO INICIAL
=================================

IMPORTANTE
Este ZIP contiene una base inicial de aplicación Android con una interfaz de prueba en español.
Todavía NO es una APK terminada y NO incluye sincronización real con DuelLinksMeta.com, base de datos
de cartas, Tier List actualizada ni constructor funcional. Esas partes se desarrollan por etapas
y no se deben presentar como si ya estuvieran listas.

REQUISITOS
- Android 14 / Samsung Galaxy A13: puede servir para probar, pero compilar en 4 GB de RAM puede ser lento.
- Termux instalado desde F-Droid: https://f-droid.org/packages/com.termux/
- Termux Studio (proyecto comunitario): https://github.com/poordevcode/termux-android-studio
- Dejar espacio libre y usar Wi-Fi.

CONTENIDO
- app/: código Android Kotlin y archivos de interfaz.
- Gradle: configuración del proyecto.
- La interfaz funciona localmente dentro de la app; requiere Internet solo cuando se incorporen fuentes online.

PRIMER PASO
1. Descargá y extraé DUEL_LINKS_META.zip con ZArchiver.
2. En Termux ejecutá:
   pkg update && pkg upgrade -y
   pkg install git curl wget unzip -y
   uname -m
3. Enviá el resultado de uname -m (por ejemplo aarch64 o armv7l) antes de continuar.
4. No intentes compilar todavía: primero verificaremos arquitectura, herramientas y ruta de la carpeta.

OBJETIVO DE LAS SIGUIENTES ETAPAS
1. Preparar el entorno de compilación en el teléfono.
2. Abrir y compilar este proyecto como APK de prueba.
3. Añadir constructor de mazos, personajes/habilidades y favoritos locales.
4. Investigar una integración fiable con Duel Links Meta y respetar nombres oficiales en español.
5. Probar, corregir y generar APK instalable.

No compartas claves ni instales APK de páginas desconocidas.
