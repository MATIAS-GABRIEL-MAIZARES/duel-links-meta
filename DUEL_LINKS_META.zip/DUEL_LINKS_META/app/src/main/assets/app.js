const panel=document.getElementById('panel');
const descriptions={
'Inicio':'Novedades, accesos y contenido destacado.',
'Mazos':'En esta etapa se preparará el constructor: monstruos, magias, trampas, Extra Deck y cantidades.',
'Cartas':'El buscador permitirá consultar cartas y sus textos en español.',
'Tier List':'La clasificación competitiva deberá sincronizarse con fuentes actualizadas.',
'Personajes':'Sección prevista para personajes y habilidades de Duel Links.',
'Favoritos':'Los mazos y cartas favoritos se guardarán localmente en el teléfono.',
'Buscar':'Búsqueda de mazos, cartas y estrategias.'
};
document.querySelectorAll('button[data-page]').forEach(btn=>btn.addEventListener('click',()=>{
 const name=btn.dataset.page;
 panel.innerHTML='<h3>'+name+'</h3><p>'+descriptions[name]+'</p><p class="note">Módulo en preparación. No se muestran datos inventados.</p>';
}));
